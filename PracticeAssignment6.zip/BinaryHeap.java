
public class BinaryHeap {
	private int[] heap;
	private int size;
	
	public BinaryHeap(){
		heap = new int[10];
		size = 0;
	}
	
	private void grow_heap(){
		int [] temp = heap;
		heap = new int[heap.length*2];
		System.arraycopy(temp, 0, heap, 0, temp.length);
	}
	
	private int parent(int i){
		return (i-1)/2;
	}
	
	private int leftChild(int i){
		return i*2 +1;
	}
	
	private int rightChild(int i){
		return i*2+2;
	}
	
	private void swap(int i, int j){
		int temp = heap[i];
		heap[i] = heap[j];
		heap[j] = temp;
	}
	
	public void add(int priority){
		if (heap.length == size)
			grow_heap();
		heap[size++]=priority;
		int index = size -1;
		
		while(heap[index] < heap[parent(index)] && index >0){
			swap(index,parent(index));
			index = parent(index);
		}
	}
	
	private void bubble_down(int i){
		int child =i;
		if (leftChild(i)<size)
			child = leftChild(i);
		if(rightChild(i)<size && heap[rightChild(i)]<heap[child])
			child = rightChild(i);
		if(heap[i]>heap[child]){
			swap(i,child);
			bubble_down(child);
		}
			
	}
	
	public int remove(){
		int temp = heap[0];
		heap[0] = heap[--size];
		bubble_down(0);
		return temp;
	}
}
